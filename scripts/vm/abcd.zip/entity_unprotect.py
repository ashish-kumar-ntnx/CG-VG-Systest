import os, sys
sys.path.append('/home/nutanix/cluster/bin')
import env
from util.interfaces.interfaces import NutanixInterfaces
interface = NutanixInterfaces()
from insights_interface.insights_interface_pb2 import *
from insights.insights_interface.cpdb_interface.cpdb_query import *
q = QUERY("dummy:entity_backup_query", SELECT=["_cas_value_"], FROM="entity_backup")
ret = interface.cpdb_impl.query(q)
update_arg = BatchUpdateEntitiesArg()
for eb in ret:
    (eb_uuid, [eb_cas]) = eb
    entity = update_arg.entity_list.add()
    entity.entity_guid.entity_type_name = "entity_backup"
    entity.entity_guid.entity_id = str(eb_uuid)
    entity.full_update = False
    entity.cas_value = 1 + eb_cas
    clear_attr_list = ["protection_rule", "protection_rule_version", "consistency_group_uuid", "consistency_group_name"]
    for clear_attr in clear_attr_list:
      attr = entity.attribute_data_arg_list.add()
      attr.attribute_data.name = clear_attr
      attr.operation = AttributeDataArg.kCLEAR
print "Clearing EntityBackups"
update_ret = interface.insights.BatchUpdateEntities(update_arg)
from util.base.types import *
from cerebro.interface.cerebro_interface_pb2 import *
list_arg = ListProtectionDomainsArg()
list_arg.protection_domain_type = 3
list_ret = interface.cerebro_client.ListProtectionDomains(list_arg)
for pd_name in list_ret.protection_domain_name:
    query_pd_arg = QueryProtectionDomainArg()
    query_pd_arg.protection_domain_name = pd_name
    query_pd_arg.list_consistency_groups.max_entries = 2
    query_pd_ret = interface.cerebro_client.QueryProtectionDomain(query_pd_arg)
    unprotect_arg = EntityUnprotectArg()
    for cg in query_pd_ret.consistency_group_vec:
      unprotect_arg.task_uuid = NutanixUuid.new().bytes
      for e in cg.entity:
        entity = unprotect_arg.entity_vec.add()
        if e.HasField("vm_hypervisor_agnostic_uuid"):
          entity.entity_type = 1
          entity.entity_uuid = e.vm_hypervisor_agnostic_uuid
        else:
          entity.entity_type = 2
          entity.entity_uuid = e.volume_group.vg_config.uuid
    if not len(unprotect_arg.entity_vec):
      continue
    print "Issuing unprotect request"
    unprotect_ret = interface.cerebro_client.EntityUnprotect(unprotect_arg)
