# Pass http path of build as argument
filename=`echo $1 | awk -F/ '{print $NF}'`
#o=`echo ab:cd:ef | rev | cut -d: -f1 | rev`
cd ~/data/installer
echo "**** Downloading $filename ****"
wget $1
echo "**** Untaring the file $filename ****"
tar xzf $filename
echo "**** Deleting file  $filename ****"
rm $filename
echo "**** Starting Upgrade ****"
cd install; ./bin/cluster -i . upgrade
